<?php
    $locaciones =
        [
            'angkor', 'azul', 'basil', 'burj',
            'colosseo', 'easter', 'eiffel',
            'gizah', 'ha-long', 'liberty',
            'machu', 'opera', 'palace', 'petra',
            'sagrada', 'santorini', 'taj',
            'wall'
        ];
    $locaciones2 =
        [
            'Cambodia'=>'angkor',
            'Turquía'=>'azul',
            'Rusia'=>'basil',
            'Dubai'=>'burj',
            'Italia'=>'colosseo',
            'Chile'=>'easter',
            'Francia'=>'eiffel',
            'Egipto'=>'gizah',
            'Vietnam'=>'ha-long',
            'USA'=>'liberty',
            'Peru'=>'machu',
            'Australia'=>'opera',
            'Tailandia'=>'palace',
            'Jordania'=>'petra',
            'España'=>'sagrada',
            'Grecia'=>'santorini',
            'India'=>'taj',
            'China'=>'wall'
        ];
    $locaciones3 =
        [
            'Angkor Wat, Angkor',
            'Mezquita azul, Estambul',
            'Catedral de San Basilio, Moscu',
            'Burj Khalifa, Dubai',
            'El Coliseo, Roma', 'Isla de Pascua, Chile',
            'Tour Eiffel, París',
            'Gran Pirámide de Guiza, Guiza',
            'Hạ Long Bay, Quang Ninh, Vietnam',
            'Estatua de la Libertad, New York',
            'Machu Picchu, Perú',
            'Opera House, Sydney', 'Grand Palace, Bangkok', 'petra',
            'La Sagrada Familia, Barcelona',
            'Santorini, Archipiélago de las Cícladas ',
            'Taj Mahal, Agra',
            'La Gran Muralla, Jinshanling'
        ];
?>
